# This includes code for making the package

log10_neut_efficacy_lookup=readRDS("./data/efficacy_lookup_table.RDS")
load("./data/natmed_2021_parameters.RData")
load("./data/natmed_2021_parameters_severe.RData")


usethis::use_data(log10_neut_efficacy_lookup, 
                  SummaryTable_Efficacy_NeutRatio_SD_SEM,
                  FittedLogistic_RawEfficacy_MeanRept_SDPool,
                  FittedLogistic_RawEfficacy_MeanRept_SDPool_Severe,
                  FittedLogistic_RawEfficacy_MeanRept_SDPool_Diff_EC50_Only,
                  internal = TRUE,
                  overwrite = TRUE)

roxygen2::roxygenise()
devtools::load_all()
devtools::build()

version = packageVersion("iaputils")
file.copy(glue::glue("../iaputils_{version}.tar.gz"),glue::glue( "../Rpackages/iaputils_{version}.tar.gz"), overwrite=T)
file.copy(glue::glue("../iaputils_{version}.tar.gz"),
          glue::glue( "~/Library/CloudStorage/OneDrive-UNSW/IAP Sharepoint - Documents/packages/iaputils_{version}.tar.gz"), overwrite=T)