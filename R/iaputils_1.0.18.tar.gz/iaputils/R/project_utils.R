#' Generate the default project structure for a new R project.
#'
#' `generate_default_project_structure` always returns true at the moment
#'
#' @details
#' It will not overwrite files that already exist.
#'
#' The default structure includes the following directories:
#' \itemize{
#'   \item `path/raw_data`
#'   \item `path/processing`
#'   \item`path/analysis`
#'   \item`path/output`
#'   \item`path/output/plots`
#'   \item`path/summaries`
#'}
#' It also includes blank files called
#' \itemize{
#'   \item `path/setup.R`
#'   \item `path/driver.R`
#'}
#' @param path The high level path into which this structure should be added. Default is the current directory
#'
#' @returns TRUE
#'
#' @examples generate_default_project_structure() generates the default project structure in the current directory
#'
#' @importFrom glue glue
#' 
#' @export 
#' 
generate_default_project_structure = function(path = './'){
  if(!endsWith(path,'/')){
    path=glue('{path}/')
  }
  if(!dir.exists(glue('{path}raw-data'))){ dir.create(glue('{path}raw-data'))}
  if(!dir.exists(glue('{path}processing'))){dir.create(glue('{path}processing'))}
  if(!dir.exists(glue('{path}analysis'))){dir.create(glue('{path}analysis'))}
  if(!dir.exists(glue('{path}R'))){dir.create(glue('{path}R'))}
  if(!dir.exists(glue('{path}obselete'))){dir.create(glue('{path}obselete'))}
  if(!dir.exists(glue('{path}output'))){dir.create(glue('{path}output'))}
  if(!dir.exists(glue('{path}output/plots'))){dir.create(glue('{path}output/plots'))}
  if(!dir.exists(glue('{path}summaries'))){dir.create(glue('{path}summaries'))}

  setup_file_exists = file.exists(glue('{path}setup.R'))
  if (!setup_file_exists) {
    file.create(glue('{path}setup.R'))
    # If setup was empty write to setup file to generate the project structure
    setup_file = file(glue('{path}setup.R'))
    writeLines(c("iaputils::generate_default_project_structure()"), setup_file)
    close(setup_file)
  }
  
  driver_file_exists = file.exists(glue('{path}driver.R'))
  if (!driver_file_exists) {
    file.create(glue('{path}driver.R'))
    # If driver was empty write to driver to source the setup file
    driver_file = file(glue('{path}driver.R'))
    writeLines(c("source(\"./setup.R\")"), driver_file)
    close(driver_file)
  }
  #Now generate the .gitignore file if it doesn't exist
  gitignore_file_exists = file.exists(glue('{path}.gitignore'))
  if (!gitignore_file_exists) {
    file.create(glue('{path}.gitignore'))
    # and write to it
    ignore_file = file(glue('{path}.gitignore'))
    writeLines(c(".Rhistory",".RData",".Ruserdata",".Rproj.user",".Rproj.user/*","**/.DS_Store","output/*","~$*","*/~$*"), ignore_file)
    close(ignore_file)
  }

  result = TRUE
  result
}

#' Source all the files in a given directory
#'
#'`source_files` returns nothing
#'
#' @details
#' It will source all the files in a given directory in alphanumerical order (by name)
#'
#' @param path The path containing the files to be sourced. \cr
#'  Default is the current directory. \cr
#'  Can be relative or absolute
#'
#' @examples
#' source_files() sources all files in the current directory
#'
#' @importFrom glue glue
#' 
#' @export
source_files = function(path = './'){
  if(!endsWith(path,'/')){
    path=glue('{path}/')
  }
  file_list = list.files(path, pattern='*.R$')
  for (file in file_list)
    source(glue('{path}{file}'))
}
