#' Generate a date as an 8 number string YYYMMDD
#'
#' `date_as_string` returns the date as an 8 number string
#'
#' @param date
#' The date to convert into a string
#' date should be a "POSIXlt" or "POSIXct"
#' Default is the current time
#'
#' @returns the date as YYYMMDD string
#'
#' @examples date_as_string() = 20230322
#'
#' @export
#'
date_as_string = function(date=Sys.time()){
  datestr= strftime(Sys.time(), format="%Y%m%d", usetz=FALSE)
  datestr
}


#' Evaluate the parameters for a log normal distribution
#'
#' `logn_params` returns the parameters for a log normal distribution
#'
#' @description This function takes ina  mean and standard deviation,
#' and outputs the log normal parameters that would define a function with such
#' a mean and standard deviation
#'
#' @param meanVal The mean of the required distribution
#' @param sdVal The standard deviation of the required distribution
#'
#' @returns
#' params A two element vector. The first element (named 'm') is the mu
#' parameter, the second element (named 's') is the sigma parameter
#'
#' @examples logn_params(10,5) = c(2.1910133,0.4723807)
#'
#' @export
#'
logn_params = function(meanVal, SDval){
  mu = log(meanVal^2/sqrt(SDval^2+meanVal^2))
  sig=sqrt(log(SDval^2/meanVal^2+1))
  params = c(mu,sig)
  names(params) = c('m','s')
  params
}

#' Evaluate the confidence intervals around a linear regression given the 
#' standard errors on the slope and intercept
#'
#' `linreg_cis` returns the upper and lower confidence intervals of a linear
#' regression line
#'
#' @description This function takes in th values of the slope and intercept 
#' parameters as weel as their standard errors and a outputs the upper 
#' and lower confidence intervals of a the regression line
#' @param x The values to enter into the regression line
#' @param slope The slope of the regression line
#' @param intercept The intercept of the regression line 
#' @param slope_se The standard error of the slope of the regression line 
#' @param intercept_se The standard error of the intercept of the regression line 
#' @param alpha The confidence level (default is .05)
#'
#' @returns
#' A data table with the following columns
#' \itemize{
#'  \item x: The input x values
#'  \item y: The predicted y values
#'  \item lower: The lower values of the confidence interval
#'  \item upper: The upper values of the confidence interval
#' }
#'
#' @examples linreg_cis(x, slope, intercept, slope_se, intercept_se)
#'
#' @export
#'

linreg_cis<-function(x, slope, intercept, slope_se, intercept_se, alpha=.05){
  # Number of bootstrap samples
  n_bootstrap <- 10000
  predicted = NULL
  bootstrap_results <- matrix(NA, nrow = n_bootstrap, ncol = length(x))
  
  #x_dummy = x
  #x=x_dummy
  #rm(x_dummy)
  # Perform bootstrap
  for (i in 1:n_bootstrap) {
    # Sample slope and intercept from their distribution
    bootstrap_slope <- rnorm(1, mean = slope, sd = slope_se)
    bootstrap_intercept <- rnorm(1, mean = intercept, sd = intercept_se)
    
    # Generate predicted values using sampled slope and intercept
    # Store predicted values in bootstrap_results
    bootstrap_results[i, ] <- bootstrap_intercept + bootstrap_slope*x
  }
  predicted = data.table(x=x, 
                         y = slope*x+intercept
  ) %>%
  mutate(lower = apply(bootstrap_results, 2, function(x) quantile(x, alpha/2, na.rm=T)),
         upper = apply(bootstrap_results, 2, function(x) quantile(x, 1 - alpha/2, na.rm=T)),
  )
  predicted
}
