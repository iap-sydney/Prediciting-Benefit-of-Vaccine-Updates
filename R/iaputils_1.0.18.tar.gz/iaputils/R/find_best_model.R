#' NEW Perform stepwise forwards regression for a logistic or linear model
#'
#'`find_best_model_forwards` performs stepwise forward regression based on AIC and
#' p-values
#'
#' @details
#' returns a model (either lm or glm) with the lowest AIC
#' containing a subset of the variables entered, where all variables have a significance
#' value below threshold
#'
#' @param datatable a dataframe containing the dat ato use in the model.
#' @param output_varname the column (in the dataframe) containing the output variable (as a string)
#' @param input_varnames the columns (in the dataframe) containing the potential
#' @param formula = NULL a formula containing themodel expression. Only one of this or output_varname and input_varnames
#' can be included
#' input variables to the model (as a vector of strings)
#' @param method = "logistic" the type of model to run. Options are "logistic" the default
#' (since ols_step_backward_p/AIC, ols_step_forward_p/AIC can be used for linear models),
#' "linear" and "ordered_logistic" (polr)
#' @param threshold = 0.05 the threshold significance value to be included in the model
#' @param conditionY = NULL subsetting condition for output variable
#' @param conditionX = NULL subsetting condition for input variables
#' @param deconvolve_factors = FALSE boolean telling whether we want to split factors up into a bunch of unrelated 0/1 variables.
#' @param force_include = NULL vector of string names of variables that
#' must be forced into the model.
#' @param show_trace Whether to print debugging output
#' #'
#' @examples
#' best_fit_cat = find_best_model_forwards(entercovid_filtered,"lymphopaenic",c(predictor_variables_cts,predictor_variables_cat), force_include ="ldh")
#'
#' @importFrom MASS polr
#' @export


# datatable is a dataframe containing the data to model
find_best_model_forwards <- function (datatable, output_varname=NULL,input_varnames=NULL,formula = NULL, method = "logistic", 
                                      threshold = 0.05,conditionY=NULL, conditionX=NULL,force_include=NULL, 
                                      deconvolve_factors = FALSE, show_trace = FALSE) {

  if (length(conditionX)==0){
    conditionX=conditionY
  }
  if (!is.null(formula)){
    formula_str = as.character(formula)
    output_varname = formula_str[2]
    
    # Separate the input variables from the formula
    input_varnames = strsplit(gsub(" ","",formula_str[3]),"\\+")[[1]]
    
  }
  
  # remove any functions applied to them
  clean_output_varname = gsub("\\)","",gsub("^[^(]*\\(","",output_varname))
  clean_input_varnames = gsub("\\)","",gsub("^[^(]*\\(","",input_varnames))
  
  # We need to make sure that we only consider the subset of the data table in which ALL potential variables are present
  datatable = filter(datatable, !if_any(c(clean_output_varname, clean_input_varnames), ~is.na(.x)))  
  
  if (deconvolve_factors){
    # Now we break up any factors
    factors_removed_struct = remove_factors(datatable, clean_output_varname, clean_input_varnames, force_include)
    
    datatable = factors_removed_struct$datatable
    input_varnames = factors_removed_struct$input_varnames
    force_include = factors_removed_struct$force_include
  } else {
    # Turn it into a dataframe
    datatable = as.data.frame(datatable)
  }
  # remove values from datatable that have an na outcome variable
  datatable = datatable[!is.na(datatable[,clean_output_varname]),]
  
  # to begin with, none are included and all are excluded except the forced ones
  included_vars = force_include
  excluded_vars = input_varnames[!(input_varnames %in% force_include)]
  lenIncl = -1
  aic_progress = NULL
  aic_current = Inf
  
  if (show_trace){
    print(paste0("find_best_model_forwards::STARTING"))
  }
  # if there are already some variables forced in
  if (!is.null(included_vars)){
    new_model_str = construct_regression_model_string(output_varname,included_vars,method,conditionY, conditionX)
    new_model = eval(parse(text = new_model_str))
    aic_current = summary.glm(new_model)$aic
    aic_progress = aic_current
  }
  # while we are refining the model
  while (length(included_vars)>lenIncl & length(excluded_vars) > 0) {
    lenIncl = length(included_vars)
    aics = NULL
    maxsig = NULL
    minsig = NULL
    for (v in 1:length(excluded_vars)) {
      # Add in this current excluded variable
      new_included_vars = c(included_vars,excluded_vars[v])
      new_model_str = construct_regression_model_string(output_varname,new_included_vars,method,conditionY, conditionX, show_trace)
      #if(show_trace) {
      #  print(new_model_str)
      #}
      new_model = eval(parse(text = new_model_str))
      #print("ran model")
      if(method == "logistic"){
        new_aic = summary.glm(new_model)$aic
      } else if (method=="linear" | method=="lm") {
        new_aic = AIC(new_model)
      } else if (method == "ordered_logistic" | method == "polr" | method == "orderedlogstic") {
        new_aic = tail(extractAIC(new_model),1)
      }
      #print(new_aic)
      aics = c(aics,new_aic) # probably should look at adjusted rsq
      if(method %in% c("lm","linear","logistic")){
        significance = (summary(new_model))$coefficients[,4]
        if (length(significance)<(length(new_included_vars)+1)){
          significance = c(significance,NA)
          names(significance) = c(rownames((summary(new_model))$coefficients),excluded_vars[v])
          significance = significance[2:length(significance)]
          significance = significance[!(names(significance) %in% force_include)]
        } else {
          significance = significance[2:length(significance)]
          significance = significance[!(names(significance) %in% force_include)]
        }
      } else if (method %in% c("ordered_logistic","orderedlogistic", "polr")){
        significance = 2*(1-pnorm(abs((summary(new_model))$coefficients[1:length(new_model$coefficients),3])))
        names(significance) = rownames(summary(new_model)$coefficients)[1:length(new_model$coefficients)]
      }
      if (is.na(significance[length(significance)])){
        new_variable_significance = 1
      } else {
        new_variable_significance = significance[startsWith(names(significance),excluded_vars[v])]
      }
      maxsig = c(maxsig,max(new_variable_significance))
      minsig = c(minsig,min(new_variable_significance))
      if(show_trace){
        print(paste0("NEW: AIC: ", round(new_aic,1)," ",names(significance)[startsWith(names(significance),excluded_vars[v])], " p=",round(new_variable_significance,5)), collapse=", ")
      }
    }
    names(aics) = excluded_vars
    names(maxsig) = excluded_vars
    names(minsig) = excluded_vars
    # Only for debugging
    #print("End of loop 1")
    if (min(aics) >= aic_current) {
      # add nothing else nothing
      #print("Nothing else to add")
    } else {
      # The next variable is the one that minimises the aic and its significance
      # is also less than the threshold for inclusion
      # If there is no such variable, we will stop at the next iteration
      next_to_include = (aics==min(aics))&(minsig<threshold)
      included_vars = c(included_vars,excluded_vars[next_to_include])
      excluded_vars = excluded_vars[!next_to_include]
      aic_progress = c(aic_progress,aics[next_to_include])
      names(aic_progress)<-included_vars
      aic_current=aics[next_to_include]
    }
  }
  # Return the model with the chosen included variables
  new_model_str = construct_regression_model_string(output_varname,included_vars,method,conditionY, conditionX)
  new_model = eval(parse(text = new_model_str))

  ans = new_model
}

#' Perform stepwise forwards regression for a logistic or linear model
#'
#'`find_best_model_backwards` performs stepwise backwards regression based on AIC and
#' p-values
#'
#' @details
#' returns a model (either lm or glm) with the lowest AIC
#' containing a subset of the variables entered, where all variables have a significance
#' value below threshold
#'
#' @param datatable a dataframe containing the dat ato use in the model.
#' @param output_varname the column (in the dataframe) containing the output variable (as a string)
#' @param input_varnames the columns (in the dataframe) containing the potential
#' @param formula = NULL a formula containing themodel expression. Only one of this or output_varname and input_varnames
#' can be included
#' input variables to the model (as a vector of strings)
#' @param method = "logistic" the type of model to run. Options are "logistic" the default
#' (since ols_step_backward_p/AIC, ols_step_forward_p/AIC can be used for linear models)
#' and "linear" Can now also include "polr" (or "ordered_logistic" or "orderedlogistic")
#' @param threshold = 0.05 the threshold significance value to be included in the model
#' @param conditionY = NULL subsetting condition for output variable
#' @param conditionX = NULL subsetting condition for input variables
#' @param force_include = NULL vector of string names of variables that
#' @param deconvolve_factors = FALSE boolean telling whether we want to split factors up into a bunch of unrelated 0/1 variables.
#' @param show_trace = FALSE Do we want to show a trace of all the models we try.
#' must be forced into the model.
#' #'
#' @examples
#' best_fit_cat = find_best_model_backwards(entercovid_filtered,"lymphopaenic",c(predictor_variables_cts,predictor_variables_cat), force_include ="ldh")
#' @importFrom MASS polr
#' @export

find_best_model_backwards <- function (datatable, output_varname=NULL,input_varnames=NULL,formula = NULL,
                                       method = "logistic", threshold = 0.05,conditionY=NULL, conditionX=NULL,force_include=NULL,
                                       deconvolve_factors = FALSE,
                                       show_trace = FALSE) {
  
  if (length(conditionX)==0){
    conditionX=conditionY
  }
  # Get the variable names from the formula if it has been entered
  if (!is.null(formula)){
    formula_str = as.character(formula)
    output_varname = formula_str[2]
    
    # Separate the input variables from the formula
    input_varnames = strsplit(gsub(" ","",formula_str[3]),"\\+")[[1]]
  }
  
  if (deconvolve_factors){
    # Now we break up any factors
    factors_removed_struct = remove_factors(datatable, output_varname, input_varnames, force_include)
  
    datatable = factors_removed_struct$datatable
    input_varnames = factors_removed_struct$input_varnames
    force_include = factors_removed_struct$force_include
  } else {
    # Turn it into a dataframe
    datatable = as.data.frame(datatable)
  }
  # remove values from datatable that have an na outcome variable
  datatable = datatable[!is.na(datatable[,output_varname]),]
  
  if (method == "ordered_logistic" | method == "polr" | method == "orderedlogstic") {
    if (!is.factor(datatable[,output_varname])){
      datatable[,output_varname] = factor(datatable[,output_varname])
    } 
  }
      
  # Length of input variables plus an extra to make sure it gets run at least once
  lenV = length(input_varnames)+1
  
  # Start with all the variables
  start_varnames = input_varnames
  current_varnames = c(input_varnames, force_include)
  error = 0
  # while we are refining the model
  while (length(current_varnames)<lenV & length(current_varnames)>0 ) {
    model_str = construct_regression_model_string(output_varname,current_varnames, method,conditionY, conditionX)
    if(show_trace) {
      print("Running model:")
      print(paste("  ",model_str))
    }
    # Try to run this model
    if (inherits(try(expr={model = eval(parse(text = model_str))}, silent = TRUE), "try-error", TRUE)) {
      # This happens if running the model throws an error
      if (method=="logistic") {
        innermodel_str = construct_internal_model_string(output_varname,current_varnames,conditionY, conditionX)
        model_str = paste0("glm(",innermodel_str,",family=binomial(\"logit\"), start=coef(lm(", innermodel_str,")))" )
        # Try again with starting values and hope this time there is no error
        if (inherits(try(expr={model = eval(parse(text = model_str))}, silent = TRUE), "try-error", TRUE)) {
          print(paste("ERROR: Couldn't Supply Start Vals for",output_varname," in datatable, current length(varnames) =",length(current_varnames)))
          print("Current model formula is:")
          print(paste("  ",model_str))
          print(geterrmessage())
          error  = 1
        } else {
          print(paste("Needed to Supply Start Vals for",output_varname," in datatable, current length(varnames) =",length(current_varnames)))
        }
      } else {
        print(paste("Error for",output_varname," in datatable, method = ",method," current length(varnames) =",length(current_varnames)))
        print("Current model formula is:")
        print(paste("  ",model_str))
        print(geterrmessage())
        error = 1
      }
    } 
    lenV = length(current_varnames)
    # This is the look that refines the variable sin the model and removes them if needed
    if (!error) {
      current_varnames = refine_var_names(current_varnames,model,force_include, method, threshold)
      error = 0
    }
  }
  # now we try to stick some of the forced ones back in in case they were deleted for being negative unnecessarily
  # get the bit before the $
  if (!error) {
    z=data.frame(lapply(start_varnames,strsplit,split="\\$"))
    #check if it's forced
    forced = start_varnames[lapply(z[1,],"%in%", force_include)==TRUE]
    # Add the forced variables that don't appear anymore
    current_varnames = c(current_varnames,forced[(forced %in% current_varnames)==FALSE])
    # refine the best model
    lenV = length(current_varnames)+1
    while (length(current_varnames)<lenV) {
      model_str = construct_regression_model_string(output_varname,current_varnames, method,conditionY, conditionX)
      
      if (inherits(try(expr={model = eval(parse(text = model_str))}, silent = TRUE), "try-error", TRUE)) {
        if (method=="logistic") {
          innermodel_str = construct_internal_model_string(output_varname,current_varnames,conditionY, conditionX) 
          model_str = paste0("glm(",innermodel_str,",family=binomial(\"logit\"), start=coef(lm(", innermodel_str,")))" )
          model = eval(parse(text = model_str))
          print(paste("Needed to Supply Start Vals for Forced section of ",regressionVar," in datatable, current length(varnames) =",length(varnames)))
        } else {
          print("Some error and not doing logistic regression")
        }
      }
      model = eval(parse(text = model_str))
      lenV = length(current_varnames)
      # Only refine variables if you have any
      if (lenV > 0) {
        current_varnames = refine_var_names(current_varnames,model,force_include, method, threshold)
      }
    }
  } else {
    model = NULL
    print("Error in find_model_backwards")
  }
  ans = model
}


# datatable is either a string with the name of the dataframe containing the
# data to model, or the dataframe itself
construct_regression_model_string = function(output_varname,input_varnames, method,conditionY, conditionX, show_trace = F) {
  inner_model_str = construct_internal_model_string(output_varname,input_varnames,conditionY, conditionX, show_trace)
  end_str = ""
  if (method == "logistic") {
    end_str = ",family=binomial(\"logit\"))"
    model_str = paste0("glm(", inner_model_str,end_str )
  } else if (method == "linear" | method == "lm") {
    end_str = ")"
    model_str = paste0("lm(", inner_model_str,end_str )
  } else if (method == "ordered_logistic" | method == "polr" | method == "orderedlogstic") {
    end_str = ", Hess=TRUE)"
    model_str = paste0("MASS::polr(", inner_model_str,end_str )
  }
  ans = model_str
}

construct_internal_model_string <- function(output_varname,input_varnames,conditionY, conditionX, show_trace=F) {
  if (length(conditionY)==0) {
    conditionStrY = ""
  } else {
    conditionStrY = "[conditionY]"
  }
  if (length(conditionY)==0) {
    conditionStrX = ""
  } else {
    conditionStrX = "[conditionX]"
  }
  if (length(input_varnames)>0) {
    model_str = paste0(output_varname,conditionStrY,"~",input_varnames[1],conditionStrX,sep="")
  } else {
    model_str = paste0(output_varname,conditionStrY,"~1",sep="")
  } 
  f = 2
  # Add the variable names
  while (f <= length(input_varnames)) {
    model_str = paste0(model_str,"+",input_varnames[f],conditionStrX,sep="")
    f = f+1
  }

  if (show_trace){
    print(paste0("construct_internal_model_string::",model_str))
  }
  model_str = paste0(model_str,", data=datatable")
  
  ans = model_str
}

refine_var_names <- function (varnames,model,force_include, method="logistic", threshold = 0.05) {
  # Should really check for a negative intercept here, but not bothering now
  #print("Current model:")
  #print(summary(model))
  
  start_ind=2
  if (method %in% c("polr","ordered_logistic","orderedlogistic")) {
    start_ind = 1
  }
  coeffs = model$coefficients[start_ind:length(model$coefficients)]
  varnames_not_in_model = sapply(varnames, function(x)(sum(startsWith(names(coeffs),x))==0 )) #| sum(is.na(coeffs[startsWith(names(coeffs),x)]))
  if(sum(varnames_not_in_model)>0){
    print(paste0("NOTE: variable(s) [",varnames[varnames_not_in_model],
                 "] were dropped from the model, possibly due to rank deficiency", collapse = "" ))
  }
  varnames = varnames[!varnames_not_in_model]
  #remove factors here, and check if we need to increment the varnames by one to account for this
  if (length(grep('factor',varnames))>0){
    start_varnames = varnames[1]
    varnames = varnames[2:length(varnames)]
    coeffs[grep('factor',names(coeffs))] = 0
    coeffs <- coeffs[coeffs != 0]
  } else{
    start_varnames=NULL
  }	
  
  nacoeffs = is.na(coeffs)
  coeffs = coeffs[!nacoeffs]
  forced_varnames = NULL
  # Remove NAs first
  if (sum(nacoeffs) > 0) {
    varnames = varnames[!nacoeffs]
  } else {
    # This is to remove negative coefficients, but I dont think I want to do that now
    # So set isNegCoeff = 0
    is_neg_coeff=0
    # isNegCoeff = coeffs < 0
    # interactions can be negative
    #isNegCoeff[grep('\\:',varnames)]=F
    #isNegCoeff[grep('INT',varnames)]=F
    
    # I don't think we need to check this for NB regression as it can't go negative.
    #if (length(grep('index',varnames))>0) {
    # index can be negative, but only provided it remains greated than the intercept
    #	isNegCoeff[grep('index',varnames)]=F
    #	indexText = paste("-min(",varnames[grep('index',varnames)],"*coeffs[grep('index',names(coeffs))])",sep="")
    #	if (eval(parse(text = indexText))>model$coefficients[1]) {
    #		isNegCoeff[grep('index',varnames)]=T
    #	}	
    #}
    if (method =="logistic"){
      significance = (summary.glm(model))$coefficients[2:length(model$coefficients),4]
    } else if (method == "lm" | method=="linear"){
      significance = (summary.lm(model))$coefficients[2:length(model$coefficients),4]
    } else {
      significance = 2*(1-pnorm(abs((summary(model))$coefficients[1:length(model$coefficients),3])))
    }
    
    # Don't remove a factor, regardless of significance
    significance[grep('factor',names(significance))] = 0
    # This is a new way to check if factors are included - we decide they are factors if more than one coefficient starts with the same variable name
    factor_varnames = varnames[sapply(varnames, function(x){sum(startsWith(names(coeffs),x))}) > 1]
    # If there are any factors, we need to look at their significance
    if (length(factor_varnames)>0){
      new_significance = rep(0, length(varnames))
      names(new_significance) = varnames
      for (varname in varnames) { 
        # If this is a factor
        if (varname %in% factor_varnames){
          var_signifs = significance[startsWith(names(significance), varname)]
          # Keep the minimum significance
          new_significance[varname] = min(var_signifs)
        } else {
          # Otherwise just copy over the significance
          new_significance[varname] = significance[startsWith(names(significance),varname)]
        }
      }
      significance = new_significance
    }
        
    # This removes values with zero significance, but I dont think we want to do this 
    # Keep an eye on if removing this line creates errors.
    # significance <- significance[significance != 0]
    
    # find the forced ones
    z=data.frame(lapply(varnames,strsplit,split="\\$"))
    #print(varnames)
    forced_inds = data.frame(lapply(z[1,],"%in%", force_include))==TRUE
    unforced_inds = !forced_inds
    if (sum(is_neg_coeff) == 0) {
      # No negative coeffs, remove least sig as long as it is > 0.05, and not a forced variable
      # Don't remove a forced variable regardless of significance
      significance <- significance[unforced_inds]
      forcedVarnames = varnames[forced_inds]
      varnames = varnames[unforced_inds]
      least_sig = ((significance == max(significance, na.rm=T)) & significance > threshold )
      varnames = varnames[!least_sig]
    } else if (sum(is_neg_coeff) == 1) {
      # Remove the negative is_neg_coeff
      varnames = varnames[!is_neg_coeff]
    } else if (sum(is_neg_coeff[unforced_inds]) >= 1) {
      # remove the highest sig, unforced negative one
      least_sig = (significance == max(significance[is_neg_coeff & unforced_inds]))
      varnames = varnames[!least_sig]
    } else {
      #remove the least significant negative one, only the forced ones are left
      least_sig = (significance == max(significance[is_neg_coeff]))
      varnames = varnames[!least_sig]
    }
  }
  varnames = c(start_varnames,forced_varnames,varnames)
  if(length(varnames)==0){
    varnames = NULL
  }
  #print(paste("Reduced varnames:"))
  #print(varnames)
  ans = varnames
}

remove_factors = function(datatable,output_varname= NULL, input_varnames = NULL, force_include = NULL) {
  new_datatable = data.frame(y=datatable[,output_varname])
  datatable = as.data.frame(datatable)
  new_varnames = NULL
  new_include = NULL
  useIntercept=1
  varnames = c(input_varnames,force_include)
  is_factors=rep(F,length(varnames))
  if (length(varnames)>0){
    for( i in c(1:length(varnames))){
      varname=varnames[i]
      this_is_factor = is.factor(datatable[,varname])
      if (varname=='0'){  #NOTE: This would cause a problem if one of names of the RHS regression values was "0" and intercept=F
        useIntercept=F
      } else if (this_is_factor){
        for (val in as.character(unique(datatable[,varname]))){
          if(!is.na(val)) {
            new_datatable$newVal = datatable[,varname]==val
            colnames(new_datatable)[colnames(new_datatable)=='newVal']=paste(varname,val, sep="_")
            is_factors[i]=T
            new_varnames = c(new_varnames,paste(varname,val, sep="_"))
          }
        }
      } else {
        new_datatable$newVal=datatable[,varname]
        colnames(new_datatable)[colnames(new_datatable)=='newVal']=varname
        new_varnames = c(new_varnames,varname)
      }
    }
  }
  # Add intercept column if necessary
  interceptName='intercept'
  if (useIntercept){
    new_datatable$intercept = 1
    # Remove one of the factors if there is one.
    if(sum(is_factors)>0){
      interceptName='intercept_'
      for ( i in c(1:sum(is_factors))){
        factor=varnames[is_factors][i]
        refName=paste(factor,as.character(sort(unique(datatable[,factor]))), sep="_")[1]
        new_datatable=select(all_of(new_datatable), -refName)
        new_varnames = new_varnames[new_varnames != refName ]
        interceptName=paste0(interceptName,refName)
      }
      colnames(new_datatable)[colnames(new_datatable)=='intercept']=interceptName
    }
  }
  output_struct = NULL
  new_input_varnames = NULL
  
  # This is if we want to force the name of the intercept
  #new_force_include = interceptName
  new_force_include = NULL
  for(var in input_varnames){
    new_input_varnames = c(new_input_varnames, new_varnames[startsWith(new_varnames,var)])
  }
  for(var in force_include){
    new_force_include = c(new_force_include, new_varnames[startsWith(new_varnames,var)])
  }
  output_struct$datatable = new_datatable
  
  output_struct$input_varnames = new_input_varnames
  output_struct$force_include = new_force_include
  output_struct
}

