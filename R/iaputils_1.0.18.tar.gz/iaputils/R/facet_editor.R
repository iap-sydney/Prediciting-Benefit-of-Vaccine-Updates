#' @title Zoom in or out for specific facet panels
#' @description 任意のfacetパネルをズームする.
#' @param panel_ranges Limits of axes or an axis.
#' @param expand Add margin to each axes or an axis, Default: TRUE
#' @param default Is this the default coordinate system? If `FALSE` (the default),
#'   then replacing this coordinate system with another one creates a message alerting
#'   the user that the coordinate system is being replaced. If `TRUE`, that warning
#'   is suppressed. NOTE: This argument explanation was cited from ggplot2::coord_cartesian
#' @param clip Should drawing be clipped to the extent of the plot panel? A
#'   setting of `"on"` (the default) means yes, and a setting of `"off"`
#'   means no. In most cases, the default of `"on"` should not be changed,
#'   as setting `clip = "off"` can cause unexpected results. It allows
#'   drawing of data points anywhere on the plot, including in the plot margins. If
#'   limits are set via `xlim` and `ylim` and some data points fall outside those
#'   limits, then those data points may show up in places such as the axes, the
#'   legend, the plot title, or the plot margins. NOTE: This argument explanation
#'   was cited from ggplot2::coord_cartesian
#' @return ggproto object
#' @details See vignette("coord_panel_ranges")
#' @references
#'  \url{https://andburch.github.io/ggplot_facets}
#'  \url{https://stackoverflow.com/questions/63550588/ggplot2coord-cartesian-on-facets}
#' @examples
#' library(frabento)
#' library(ggplot2)
#' library(magrittr)
#' 
#' theme_set(theme_linedraw(base_family = "Helvetica", base_line_size = 0.3) +
#'           theme(aspect.ratio = 1/1, legend.position = c(0.75, 0.25)))
#' 
#' ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width)) +
#'     geom_point(aes(color = Species)) +
#'     geom_rect(data = .  %>% dplyr::filter(Species == "versicolor"),
#'               xmin = 5.5, xmax = 6.5, ymin = 2.5, ymax = 3,
#'               color = "red", linewidth = 1, fill = NA) +
#'     facet_wrap(~ Species, scale = "free", ncol = 2) +
#'     coord_panel_ranges(panel_ranges = list(
#'         list(NULL),
#'         list(x = c(5.4, 6.6), y = c(2.4, 3.1)),
#'         list(NULL)
#'     ))
#' @seealso
#'  \code{\link[ggplot2]{ggproto}}
#'  \code{\link[ggplot2]{coord_cartesian}}
#' @rdname coord_panel_ranges
#' @import ggplot2
#' @export

coord_panel_ranges <- function(panel_ranges, expand = TRUE, default = FALSE,
                               clip = "on") {
  UniquePanelCoords <- ggplot2::ggproto(
    "UniquePanelCoords", ggplot2::CoordCartesian,
    
    num_of_panels = 1,
    panel_counter = 1,
    panel_ranges = NULL,
    
    setup_layout = function(self, layout, params) {
      self$num_of_panels <- length(unique(layout$PANEL))
      self$panel_counter <- 1
      layout
    },
    
    setup_panel_params =  function(self, scale_x, scale_y, params = list()) {
      if (!is.null(self$panel_ranges) & length(self$panel_ranges) != self$num_of_panels)
        stop("Number of panel ranges does not equal the number supplied")
      
      train_cartesian <- function(scale, limits, name, given_range = NULL) {
        if (is.null(given_range)) {
          #         range <- ggplot2:::scale_range(scale, limits, self$expand)
          expansion <- ggplot2:::default_expansion(scale, expand = self$expand)
          range <- ggplot2:::expand_limits_scale(scale, expansion,
                                                 coord_limits = self$limits[[name]])
        } else {
          range <- given_range
        }
        
        #       out <- scale$break_info(range)
        #       out$arrange <- scale$axis_order()
        #       names(out) <- paste(name, names(out), sep = ".")
        #       out
        out <- list(
          ggplot2:::view_scale_primary(scale, limits, range),
          sec = ggplot2:::view_scale_secondary(scale, limits, range),
          arrange = scale$axis_order(),
          range = range
        )
        names(out) <- c(name, paste0(name, ".", names(out)[-1]))
        out
      }
      
      cur_panel_ranges <- self$panel_ranges[[self$panel_counter]]
      if (self$panel_counter < self$num_of_panels)
        self$panel_counter <- self$panel_counter + 1
      else
        self$panel_counter <- 1
      
      c(train_cartesian(scale_x, self$limits$x, "x", cur_panel_ranges$x),
        train_cartesian(scale_y, self$limits$y, "y", cur_panel_ranges$y))
    }
  )
  ggplot2::ggproto(NULL, UniquePanelCoords, panel_ranges = panel_ranges,
                   expand = expand, default = default, clip = clip)
}

#' tag_facet
#'
#' @description Adds a dummy text layer to a ggplot to label facets and sets facet strips to blank. 
#' This is the typical formatting for some journals that consider facets as subfigures 
#' and want to minimise margins around figures.
#' @param p ggplot
#' @param open opening character, default: (
#' @param close  closing character, default: )
#' @param tag_pool character vector to pick tags from
#' @param x x position within panel, default: -Inf
#' @param y y position within panel, default: Inf
#' @param hjust hjust
#' @param vjust vjust
#' @param fontface fontface
#' @param family font family
#' @param ... further arguments passed to geom_text layer
#'
#' @return plot with in-panel tags 
#' @importFrom ggplot2 geom_text ggplot_build theme element_blank aes_string
#' @export
#' @examples
#' library(ggplot2)
#' mydf = data.frame(
#'   x = 1:90,
#'   y = rnorm(90),
#'   red = rep(letters[1:3], 30),
#'   blue = c(rep(1, 30), rep(2, 30), rep(3, 30)))
#' 
#' p <- ggplot(mydf) +
#'   geom_point(aes(x = x, y = y)) +
#'   facet_wrap(
#'     ~ red + blue)
#' tag_facet(p)

tag_facet <- function(p, open = "", close = "", tag_pool = toupper(letters), x = -Inf, y = Inf, 
                      hjust = -0.5, vjust = 1.5, fontface = 2, family = "", ...) {
  
  gb <- ggplot_build(p)
  lay <- gb$layout$layout
  tags <- cbind(lay, label = paste0(open, tag_pool[lay$PANEL], close), x = x, y = y)
  p + geom_text(data = tags, aes_string(x = "x", y = "y", label = "label"), ..., hjust = hjust, 
                vjust = vjust, fontface = fontface, family = family, inherit.aes = FALSE) 
}


#' tag_facet_outside
#'
#' @description Adds a dummy text layer to a ggplot to label facets and sets facet strips to blank. 
#' This is the typical formatting for some journals that consider facets as subfigures 
#' and want to minimise margins around figures.
#' @param p ggplot
#' @param open opening character, default: (
#' @param close  closing character, default: )
#' @param tag_fun_top labelling function 
#' @param tag_fun_right labelling function
#' @param x x position within cell
#' @param y y position within cell
#' @param hjust hjust
#' @param vjust vjust
#' @param fontface fontface
#' @param family font family
#' @param draw logical: draw the resulting gtable
#' @param ... further arguments passed to geom_text layer
#' @return plot with in-panel tags 
#' @importFrom ggplot2 ggplot_gtable geom_text ggplot_build theme element_blank 
#' @importFrom utils as.roman
#' @export
#' @examples
#' library(ggplot2)
#' d = data.frame(
#'   x = 1:90,
#'   y = rnorm(90),
#'   red = rep(letters[1:3], 30),
#'   blue = c(rep(1, 30), rep(2, 30), rep(3, 30)))
#' 
#' p <- ggplot(d) +
#'   geom_point(aes(x = x, y = y)) +
#'   facet_grid(red ~ blue)
#'   
#' tag_facet_outside(p)
#' 
tag_facet_outside <-  function(p, open=c("(",""), close = c(")","."),
                               tag_fun_top = function(i) toupper(letters[i]),
                               tag_fun_right = utils::as.roman,
                               x = c(0,0), y = c(0.5, 1),
                               hjust = c(0,0), vjust = c(0.5,1), 
                               fontface = c(2,2), family="", draw = TRUE, ...){
  
  gb <- ggplot_build(p)
  lay <- gb$layout$layout
  
  tags_top <- paste0(open[1],tag_fun_top(unique(lay$COL)),close[1])
  tags_right <- paste0(open[2],tag_fun_right(unique(lay$ROW)),close[2])
  
  tl <- lapply(tags_top, grid::textGrob, x=x[1], y=y[1],
               hjust=hjust[1], vjust=vjust[1], 
               gp=grid::gpar(fontface=fontface[1], fontfamily = family, ...))
  rl <- lapply(tags_right, grid::textGrob, x=x[2], y=y[2],
               hjust=hjust[2], vjust=vjust[2], 
               gp=grid::gpar(fontface=fontface[2], fontfamily = family, ...))
  
  
  g <- ggplot_gtable(gb)
  g <- gtable::gtable_add_rows(g, grid::unit(1,"line"), pos = 0)
  l <- unique(g$layout[grepl("panel",g$layout$name), "l"])
  g <- gtable::gtable_add_grob(g, grobs = tl, t=1, l=l)
  
  wm <- do.call(grid::unit.pmax, lapply(rl, grid::grobWidth))
  g <- gtable::gtable_add_cols(g, wm, pos = max(l))
  t <- unique(g$layout[grepl("panel",g$layout$name), "t"])
  g <- gtable::gtable_add_grob(g, grobs = rl, t=t, l=max(l) + 1)
  g <- gtable::gtable_add_cols(g, unit(2,"mm"), pos = max(l))
  
  if(draw){
    grid::grid.newpage()
    grid::grid.draw(g)
  }
  invisible(g)
}