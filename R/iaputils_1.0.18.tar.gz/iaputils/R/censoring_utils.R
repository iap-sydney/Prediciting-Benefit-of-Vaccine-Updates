#' Evaluate the censored mean
#'
#'`censored_mean` evaluates the censored mean across some groups
#'
#' @details
#' return the censored mean
#'
#' @param data a dataframe containing the data
#' @param value_name the column (in the dataframe) containing the variable for which we want to calculate the mean
#' @param use_log10 A boolean indicating if the log 10 of the value should be considered. Defaults to FALSE.
#' @param groups The groups across which we want to calculate the means. This could be a vector of group names. Defaults to NULL.
#' @param censored_below The name of the column giving details of the entries that are censored from below (0 for uncensored, 1 for censored)
#' or a vector with the same length as the number of rows in the dataset. Defaults to NULL.
#' @param censored_above The name of the column giving details of the entries that are censored from above (0 for uncensored, 1 for censored)
#' or a vector with the same length as the number of rows in the dataset. Defaults to NULL.'
#' @param initial_guess A vector of the form (mu_guess, sigma_guess) which can take the place of the automatically generated guess.
#' @examples
#' censored_mean(dataframe, "height", use_log10=FALSE, groups=c("sex","age_group"), censored_below="too_short", censored_above="too_tall")
#'
#' @returns a data frame where each row represents a unique combination of the groups available in the data.
#' The dataframe has the following columns:
#' 
#' \itemize{
#'   \item groups(1...n): the different groups
#'   \item muL: the estimated mean
#'   \item sigL: the estimated sigma (assuming the data is from a normal distribution)
#'   \item seL: the estimated standard error of the mean
#'   \item lower95L: lower 95% CIs
#'   \item upper95L: upper 95% CIs 
#'   \item exitflag: the exitflag from the liklihood fitting (taken from the nlm function)\\
#'   1: relative gradient is close to zero, current iterate is probably solution.\\
#'   2: successive iterates within tolerance, current iterate is probably solution.
#'   3: last global step failed to locate a point lower than estimate. Either estimate is an approximate local minimum of the function or steptol is too small.\\
#'   4: iteration limit exceeded.\\
#'   5: maximum step size stepmax exceeded five consecutive times. Either the function is unbounded below, becomes asymptotic to a finite value from above in some direction or stepmax is too small.
#'   \item n: the number o fentries contributing to the mean estimate
#'   \item Q1lower: the lower 25% quartile of the data
#'   \item Q4upper: the upper 25% quartile of the data
#'   \item mu_guess: the initial mean guess (based on uncensored data only)
#'   \item sig_guess: the initial sigma guess (based on uncensored data only)
#'}
#'
#' @export

censored_mean <- function (data, value_name, use_log10=FALSE, groups=NULL, censored_below=NULL, censored_above=NULL, initial_guess=NULL){
  
  # Turn it into a data.frame, as for a data.table it seems you cannot select columns by name
  data = as.data.frame(data)
  ###Make Table
  if(length(groups)==0){
    censored_means = data.frame("grouping"="All")
  } else if(length(groups)==1){
    censored_means<-data.frame(x=unique(data[,groups]))
    colnames(censored_means)=groups
  } else{
    censored_means=unique(data[,groups])
  }
  
  # remove NA rows
  for (i in c(1:nrow(censored_means))){
    if (sum(is.na(censored_means[i,]))>0){
      # remove this row
      censored_means[i,]=NA
    }
  }
  censored_means = subset(censored_means,!is.na(censored_means[,1]))
  # add censored below and censored above
  # check censored has been entered
  
  if (is.null(censored_below)){
    censored_below = rep(F, nrow(data))
  } else if (class(censored_below) == "character" & length(censored_below)==1){
    if (sum(colnames(data)==censored_below)==0){
      simpleError('Error: censored_below must be a valid name of a column of the dataset')
    }
    censored_below = data[,censored_below]
  } else if (length(censored_below)!=nrow(data)) {
    simpleError('Error: length of censored_below must be the same as the number of rows in the dataset')
  }
  
  if (is.null(censored_above)){
    censored_above = rep(F, nrow(data))
  } else if (class(censored_above) == "character" & length(censored_above)==1){
    if (sum(colnames(data)==censored_above)==0){
      simpleError('Error: censored_above must be a valid name of a column of the dataset')
    }
    censored_above = data[,censored_above]
  } else if (length(censored_above)!=nrow(data)) {
    simpleError('Error: length of censored_above must be the same as the number of rows in the dataset')
  }
  uncensored = !(censored_below|censored_above)
  data$censored_below = censored_below
  data$censored_above = censored_above
  data$uncensored = uncensored
  
  # Remove NA values
  data=data[!is.na(select(data,value_name)),]
  
  # take log10 if required
  if (use_log10){
    data[,value_name] = log10(data[,value_name])
  }
  #Determine the number of studies in each group
  #eval(expr = str2expression(paste0('censored_means<-data %>% group_by(',paste0(groups,collapse=','),') %>% summarise(nstudy=length(unique(PaperRef)))')))  
  censored_means<-data.frame(censored_means)
  
  
  censored_means$mu_guess<-NA
  censored_means$sig_guess<-NA
  censored_means$muL<-NA
  censored_means$sigL<-NA
  censored_means$exitflag<-NA
  censored_means$negloglikelihood<-NA
  censored_means$n<-NA
  censored_means$Q1lower=NA
  censored_means$Q4upper=NA
  
  # This is for every row int he output table that we are generating
  for (i in 1:nrow(censored_means)){
    # Set the initial guess to the input value
    initialguess = initial_guess
    temp=data
    temp_censored_below=data$censored_below #[data$censoredWT==0]
    temp_censored_above=data$censored_above
    # Select the data for each group
    if (length(groups)>0) {
      for (j in c(1:length(groups))){
        useInds=(temp[,groups[j]]==censored_means[i,j] & !is.na(temp[,groups[j]]))
        temp=temp[useInds,]
        temp_censored_below=temp_censored_below[which(useInds)]
        temp_censored_above=temp_censored_above[which(useInds)]
      }
    }
    # remove NA values (again)
    useInds=!is.na(temp[,value_name])
    temp=temp[useInds,]
    temp_censored_below=temp_censored_below[which(useInds)]
    temp_censored_above=temp_censored_above[which(useInds)]
    temp_uncensored = !(temp_censored_below|temp_censored_above)
    temp_notNA = !is.na(temp[,value_name])
    # Can't continue with no data
    if (nrow(temp)!=0 & nrow(temp[temp_uncensored,])!=0 ){
      if (is.null(initialguess)){
        # This uses uncensored values only
        #initialguess<-c(mean(temp[temp_uncensored,value_name]),sd(temp[temp_uncensored,value_name]))
        # This uses censored values as well
        initialguess<-c(mean(temp[temp_notNA,value_name]),sd(temp[temp_notNA,value_name]))
      }
      #print(initialguess)
      if (initialguess[2]==0 | is.na(initialguess[2])){
        censored_means$mu_guess[i]<-initialguess[1]
        censored_means$sig_guess[i]<-initialguess[2]
        censored_means$muL[i]<-initialguess[1]
        censored_means$sigL[i]<-initialguess[2]
      } else {
        tempfit<-nlm(function(x)likelihoodfunc(temp[,value_name],temp_censored_below, temp_censored_above,x[1],x[2]),initialguess, iterlim = 1000)
        censored_means$mu_guess[i]<-initialguess[1]
        censored_means$sig_guess[i]<-initialguess[2]
        censored_means$muL[i]<-tempfit$estimate[1]
        censored_means$sigL[i]<-tempfit$estimate[2]
        censored_means$exitflag[i]<-tempfit$code
        censored_means$negloglikelihood[i]<-tempfit$minimum
        censored_means$n[i]<-nrow(temp)
      }
      censored_means$Q1lower[i]=quantile(temp[,value_name])[4]
      censored_means$Q4upper[i]=quantile(temp[,value_name])[2]
    }
    #print(i)
  }
  
  censored_means$seL=censored_means$sigL/sqrt(censored_means$n)
  censored_means$lower95L=censored_means$muL-censored_means$seL*1.96
  censored_means$upper95L=censored_means$muL+censored_means$seL*1.96
  #reorder
  #print(colnames(censored_means))
  censored_means = censored_means[,c(groups, "muL","sigL","seL","lower95L","upper95L","exitflag","n","Q1lower","Q4upper","mu_guess","sig_guess")]
  
  # colnames(censored_means)[colnames(censored_means)=='muL']=paste('muL',value_name,paste(substr(groups,1,3),collapse = '_'),sep='_')
  # colnames(censored_means)[colnames(censored_means)=='sigL']=paste('sigL',value_name,paste(substr(groups,1,3),collapse = '_'),sep='_')
  # colnames(censored_means)[colnames(censored_means)=='seL']=paste('seL',value_name,paste(substr(groups,1,3),collapse = '_'),sep='_')
  # colnames(censored_means)[colnames(censored_means)=='Q1cut']=paste('Q1cut',value_name,paste(substr(groups,1,3),collapse = '_'),sep='_')
  # colnames(censored_means)[colnames(censored_means)=='Q4cut']=paste('Q4cut',value_name,paste(substr(groups,1,3),collapse = '_'),sep='_')
  censored_means
  
}


####Model Fold Change
likelihoodfunc<-function(values,censoredBelow, censoredAbove,mu_log10,sig){
  # Cant have a negative std dev
  if (sig<0) sig=0
  uncensored=!(censoredBelow|censoredAbove)
  NLL=-sum(dnorm(values[uncensored],mu_log10,sig,log=T))
  NLL=NLL - sum(pnorm(values[censoredBelow],mu_log10,sig,log=T))
  NLL=NLL - sum(pnorm(values[censoredAbove],mu_log10,sig,lower.tail = F,log=T))
  NLL
}


#' Evaluate the censored mean
#'
#'`censored_regression` evaluates the censored mean across some groups
#'
#' @details
#' do censored regression with varying LODs
#'
#' @param dataset a dataframe containing the data
#' @param yVar the name of the columns (in the dataframe) containing the variable
#' to be used as the dependant variable, input as a string
#' @param xVars the names of the columns (in the dataframe) containing the variables 
#' to be used as the independant variables, input as a vector of strings.
#' @param intercept A boolean determining whether the model should have a constant term. Default is TRUE
#' @param censored_below The name of the column giving details of the entries that are censored from below (0 for uncensored, 1 for censored)
#' or a vector with the same length as the number of rows in the dataset. Defaults to NULL.
#' @param censored_above The name of the column giving details of the entries that are censored from above (0 for uncensored, 1 for censored)
#' or a vector with the same length as the number of rows in the dataset. Defaults to NULL.
#' @examples
#' censored_regression(dataset,yVar = "height",xVars=c("sex","age_group"),intercept=TRUE, censored_below="too_short", censored_above="too_tall")
#'
#' @returns a list that has the following entries
#' \itemize{
#'   \item linearModel
#'   \item uncensoredModel
#'   \item censoredModel 
#'   \item modelFormula
#' }
#' 
#' Each of the first three entries is a "Model" which has the following elements
#' \itemize{
#'   \item coeff: The regression coefficients
#'   \item neglogLik: The negative log likelihood value of the regression.
#'   \item AIC: The AIC of the regression
#'   \item df: The degrees of freedom of the model
#'   \item sigma: lThe standard deviation of the residuals of the model
#'}
#'
#' @export
censored_regression<-function(dataset,yVar,xVars,intercept=TRUE, censored_below = NULL, censored_above = NULL){
  minParamVal = -1e7
  maxParamVal = 1e7
  
  # Can only perform regression on data that has a y-value
  dataset=dataset[!is.na(dataset[,yVar]),]
  
  if (length(xVars)==0){
    modelFormula = paste(yVar,'~1')
  } else {
    i=1
    xVars=sort(xVars)
    modelFormula = paste(yVar,'~',xVars[i])
    
    while (length(xVars)>i){
      i=i+1
      modelFormula = paste(modelFormula,'+',xVars[i])
    }
    if (intercept==F){
      modelFormula = paste(modelFormula,'+ 0')
    }
  }
  # model is an uncensored regression 
  uncensored_model=lm(as.formula(modelFormula), data=dataset)
  
  # Create a new dataframe on which to preform the regression
  regData = data.frame(y=dataset[,yVar])
  
  # Add intercept columns (for true intercept or factors)
  useIntercept=intercept
  # check if any of othe x variables are factors, and if so, add them as intercepts. 
  #Dont add NA values
  isFactors=rep(F,length(xVars))
  if (length(xVars)>0){
    for( i in c(1:length(xVars))){
      xvar=xVars[i]
      if (xvar=='0'){  #NOTE: This would cause a problem if one of names of the RHS regression values was "0" and intercept=F
        useIntercept=F
      } else if (is.factor(dataset[,xvar])){
        for (val in as.character(unique(dataset[,xvar]))){
          if(!is.na(val) & val != "NA") {
            regData$newVal = dataset[,xvar]==val
            colnames(regData)[colnames(regData)=='newVal']=paste0(xvar,val)
            isFactors[i]=T
          }
        }
      } else {
        regData$newVal=dataset[,xvar]
        colnames(regData)[colnames(regData)=='newVal']=xvar
      }
    }
  }
  # Add intercept column if necessary
  interceptName='intercept'
  if (useIntercept){
    regData$intercept = 1
    # Remove one of the factors if there is one.
    if(sum(isFactors)>0){
      interceptName='intercept_'
      for ( i in c(1:sum(isFactors))){
        factor=xVars[isFactors][i]
        refName=paste0(factor,as.character(sort(unique(dataset[,factor]))))[1]
        regData=select(regData, -refName)
        interceptName=paste0(interceptName,refName)
      }
      colnames(regData)[colnames(regData)=='intercept']=interceptName
    }
  }
  
  #get the censored values
  censLow=dataset[,censored_below]
  censHigh=dataset[,censored_above]
  
  # Get the starting parameters from the uncensored model
  initParams=uncensored_model$coefficients
  names(initParams)[names(initParams)=='(Intercept)']=interceptName
  initParams=initParams[order(names(initParams))]
  # Extract residual standard deviation of the uncensored model
  initParams[length(initParams)+1]=sigma(uncensored_model)
  names(initParams)[length(initParams)]='sig'
  
  
  lowerB=rep(minParamVal,length(initParams))
  # Lower bound on sigma
  lowerB[length(lowerB)]=1e-5
  upperB=rep(maxParamVal,length(initParams))
  if(sum(is.na(initParams))>0){
    # Dont regress if NA values
    resUncens=NA
    resCens=NA
  } else {
    resUncens=runCensoredRegression(initParams,'NLLcensoredRegression',regData,lowerB,upperB)
    resCens=runCensoredRegression(initParams,'NLLcensoredRegression',regData,lowerB, upperB,censLo=censLow, censHi=censHigh)
  }
  reslm=make_regression_struct(uncensored_model)
  result=list(linearModel=reslm,uncensoredModel=resUncens, censoredModel=resCens, modelFormula=modelFormula)
}


runCensoredRegression = function(initParams,func,data,lowerB=-Inf,upperB=Inf,censLo=NULL,censHi=NULL,fitmethod="L-BFGS-B",hess=T){
  # make sure bounds are the right length
  if (length(lowerB)==1){
    lowerB=rep(lowerB,length(initParams))
  }
  if (length(upperB)==1){
    upperB=rep(upperB,length(upperB))
  }
  regressionString = paste0('regressionResult = optim(par = initParams, fn = ',func,', regData=data,censLow=censLo,censHigh=censHi, lower=lowerB, upper=upperB, method=fitmethod, hessian=hess)')
  eval(parse(text=regressionString))
  ests=head(regressionResult$par,-1)
  stderrs=head(sqrt(diag(solve(regressionResult$hessian))),-1)
  tvals=ests/stderrs
  coeffs=data.frame(Estimate=head(regressionResult$par,-1),StdErr=stderrs,tValue=tvals)
  df = nrow(data)-length(regressionResult$par)
  pvals=2*pt(-abs(tvals), df=df)
  
  regressionCoeff=data.frame(Estimate=ests,StdErr=stderrs,tValue=tvals,pValue=pvals, significance=isSignificant(pvals))
  regressionNeglogLik=regressionResult$value
  regResult=list(coeff=regressionCoeff, neglogLik=regressionNeglogLik, AIC=2*(length(regressionResult$par)+regressionNeglogLik),df=df, sigma=regressionResult$par[length(regressionResult$par)])
}

NLLcensoredRegression = function(params, regData,censLow=NULL,censHigh=NULL) {
  # Values predicted by the model
  ydata=regData$y
  
  xdataInds = !(colnames(regData) %in% c('y'))
  xdata=regData[,xdataInds]
  if (is.data.frame(xdata)) {
    xdata=xdata[,order(colnames(regData)[xdataInds])]
  } else {
    xdata=data.frame(xdata)
    colnames(xdata)<-colnames(regData)[xdataInds]
  }
  
  coeffs=head(params,-1)
  coeffs=as.data.frame(matrix(rep(coeffs,nrow(xdata)),ncol=length(coeffs),byrow=T))
  estimates = rowSums(xdata*coeffs)
  sig=tail(params,1)
  
  # determine censoring
  if (is.null(censLow)){
    censLow=rep(FALSE,length(ydata))
  }
  if (is.null(censHigh)){
    censHigh=rep(FALSE,length(ydata))
  }
  uncensored = !(censLow|censHigh)
  
  # Negative log-likelihood 
  NLLinRange=-sum(dnorm(ydata[uncensored], mean = estimates[uncensored], sd = sig,log=T), na.rm=T)
  NLLbelowLOD=-sum(pnorm(ydata[censLow], mean = estimates[censLow], sd = sig,log=T), na.rm=T)
  NLLaboveLOD=-sum(pnorm(ydata[censHigh], mean = estimates[censHigh], lower.tail = F, sd = sig,log=T), na.rm=T)
  NLL=NLLinRange+NLLbelowLOD+NLLaboveLOD
  if(is.nan(NLL)){
    NLL=length(data$y)
  }
  #print(c(params,NLL))
  NLL
}

isSignificant = function(pvals){
  isSig=rep(' ',length(pvals))
  isSig[pvals<.1]='.'
  isSig[pvals<.05]='*'
  isSig[pvals<.01]='**'
  isSig[pvals<.001]='***'
  isSig
}

make_regression_struct=function(model){
  vars = as.character(attr(summary(model)$terms,'variables'))
  offsets=vars[startsWith(vars,'offset')]
  
  struct=list(coeff=as.data.frame(summary(model)$coeff),
              neglogLik=-logLik(model), 
              AIC=2*(length(model$coefficients)+1-logLik(model)),
              df=summary(model)$df[2], 
              sigma=sigma(model)
              )
  struct$coeff$significance=isSignificant(summary(model)$coeff[,4])
  struct
}

