#' Evaluate the power associated with a certain effect size
#'
#'`power_two_means` evaluates the power associated with a certain effect size
#'
#' @details
#' Evaluate the power associated with a certain effect size
#'
#' @param group_size number in the first group
#' @param r the ratio in group sizes between first and second group (note r<1)
#' @param effect_size the ratio between teh expected difference in means and the pooled standard deviation of the two groups
#' @param significance = 0.05 significance cutoff
#' 
#' #' @examples
#' power_two_means(10,.5, 1 ,.05) = 
#' @returns The power associated with this experimental setup
#' 
#'
#' @export
#' 

power_two_means = function(group_size, r=1, effect_size=1, significance=.05) {
  z_power = sqrt(group_size*r*effect_size^2) - qnorm(1-significance/2)
  power = pnorm(z_power)
}