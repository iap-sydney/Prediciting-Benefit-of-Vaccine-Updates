library(data.table)

#' Extract the parameters from the khoury et al nature med 2021 paper as a list
#'
#' `get_natmed2021_params` returns a list of parameters
#'
#' @returns A list with the following fields:
#' sig, logk, C50, C50_Severe
#'
#' @examples get_natmed2021_params()
#'
#' @export
#'
get_natmed2021_params = function(){
  # Extract parameters that aren't going to change
  #load('natmed_2021_parameters.RData')
  
  params = list()
  params$sig=SummaryTable_Efficacy_NeutRatio_SD_SEM$PooledSD[1]
  params$sig_sd=SummaryTable_Efficacy_NeutRatio_SD_SEM$SE_PooledSD[1]
  
  cov_hill_IC50<-solve(FittedLogistic_RawEfficacy_MeanRept_SDPool$hessian)[9:10,9:10]
  sd_hill_IC50=sqrt(diag(cov_hill_IC50))
  
  
  logk_C50=c(tail(FittedLogistic_RawEfficacy_MeanRept_SDPool$estimate,2))
  params$logk = logk_C50[1]
  params$C50=logk_C50[2]
  
  cov_logk_C50<-solve(FittedLogistic_RawEfficacy_MeanRept_SDPool$hessian)[9:10,9:10]
  sd_logk_C50=sqrt(diag(cov_logk_C50))
  params$logk_sd = sd_logk_C50[1]
  params$C50_sd = sd_logk_C50[2]
  
  logk_C50_severe=c(tail(FittedLogistic_RawEfficacy_MeanRept_SDPool_Diff_EC50_Only$estimate,3))[1:2]
  params$logk_Severe = logk_C50_severe[1]
  params$C50_Severe = logk_C50_severe[2]
  
  cov_logk_C50_severe = solve(FittedLogistic_RawEfficacy_MeanRept_SDPool_Diff_EC50_Only$hessian)[15:16,15:16]
  sd_hill_IC50_severe=sqrt(diag(cov_logk_C50_severe))
  params$logk_severe_sd = sd_hill_IC50_severe[1]
  params$C50_severe_sd = sd_hill_IC50_severe[2]
  
  # Fitted IC50 values
  params$C50_Severe_A=tail(FittedLogistic_RawEfficacy_MeanRept_SDPool_Severe$estimate,1)
  # Guessed IC50 values
  #C50_Death = -1.8
  #C50_Infection = -.3
  #C50_Transmission = 0
  params
}


#' Get the efficacy from the neuts (raw, not log10) for a homogeneous population. 
#' This is the underlying logistic curve
#'
#' `underlying_logistic_curve` returns the neut values for a given efficacy
#'
#' @description This function takes in a an efficacy value and type and 
#' returns the corresponding neut value according to the Khoury curve
#'
#' @param neut The neutralisation titre (as a fold of convalescent titre)
#' @param efficacy_type the type of efficacy where efficacy types can be:
#' \itemize{
#'   \item 1 = transmission
#'   \item 2 = infection
#'   \item 3 = symptomatic
#'   \item 4 = severe
#'   \item 5 = death
#'}
#'
#' eff The VE (for this VE type) that would arise from this 
#' neutralising antibody titre (as a fold of convalescent)
#'
#' @examples underlying_logistic_efficacy_from_neut(1,3) = 1=80
#'
#' @export

underlying_logistic_efficacy_from_neut = function(neut, efficacy_type=3){
  params = get_natmed2021_params()
  if (efficacy_type==4){
    k = exp(params$logk_Severe)
    IC50 = params$C50_Severe
    k_lo = exp(params$logk_Severe-1.96*params$logk_severe_sd)
    k_hi = exp(params$logk_Severe+1.96*params$logk_severe_sd)
    IC50_lo = params$C50_Severe - 1.96*params$C50_severe_sd
    IC50_hi = params$C50_Severe + 1.96*params$C50_severe_sd
    
  } else { #if (k == 3)
    k = exp(params$logk)
    IC50 = params$C50
    k_lo = exp(params$logk-1.96*params$logk_sd)
    k_hi = exp(params$logk+1.96*params$logk_sd)
    IC50_lo = params$C50 - 1.96*params$C50_sd
    IC50_hi = params$C50 + 1.96*params$C50_sd
  } 
  eff = 1/(1+exp(-k*(log10(neut)-IC50)))
  eff
}

#' Get the neuts (raw, not log10) for a homogeneous population from a VE
#' This is the underlying logistic curve
#'
#' `underlying_logistic_curve` returns the neut values for a given efficacy
#'
#' @description This function takes in a neut value and type and 
#' returns the corresponding efficacy according to the underlying logistic 
#' function of the Khoury curve
#'
#' @param VE The VE (for this VE type)
#' @param efficacy_type the type of efficacy where efficacy types can be:
#' \itemize{
#'   \item 1 = transmission
#'   \item 2 = infection
#'   \item 3 = symptomatic
#'   \item 4 = severe
#'   \item 5 = death
#'}
#'
#' neut The neutralising antibody titre (as a fold of convalescent) that would
#' give this VE (for this VE type)
#'
#' @examples underlying_logistic_neut_from_efficacy(1,3) = 1=80
#'
#' @export

underlying_logistic_neut_from_efficacy = function(VE, efficacy_type=3){
  params = get_natmed2021_params()
  if (efficacy_type==4){
    k = exp(params$logk_Severe)
    IC50 = params$C50_Severe
    k_lo = exp(params$logk_Severe-1.96*params$logk_severe_sd)
    k_hi = exp(params$logk_Severe+1.96*params$logk_severe_sd)
    IC50_lo = params$C50_Severe - 1.96*params$C50_severe_sd
    IC50_hi = params$C50_Severe + 1.96*params$C50_severe_sd
    
  } else { #if (k == 3)
    k = exp(params$logk)
    IC50 = params$C50
    k_lo = exp(params$logk-1.96*params$logk_sd)
    k_hi = exp(params$logk+1.96*params$logk_sd)
    IC50_lo = params$C50 - 1.96*params$C50_sd
    IC50_hi = params$C50 + 1.96*params$C50_sd
  } 
  neut= 10^(-log(1/VE-1)/k+IC50)
  neut
}

# Use a lookup table and set the key of the table to the log10 neut ratios
# I probably need to think about how to keep this only loaded once, but in memory always, but not visual?
#log10_neut_efficacy_lookup=readRDS("efficacy_lookup_table.RDS")

# Lookup functions
#' Get the neuts (raw, not log10) for a given vaccine efficacy
#'
#' `get_neut_from_efficacy` returns the neut values for a given efficacy
#'
#' @description This function takes in a an efficacy value and type and 
#' returns the corresponding neut value according to the Khoury curve
#'
#' @param VE The vaccine efficacy
#' @param efficacy_type the type of efficacy where efficacy types can be:
#' \itemize{
#'   \item 1 = transmission
#'   \item 2 = infection
#'   \item 3 = symptomatic
#'   \item 4 = severe
#'   \item 5 = death
#'}
#'
#' @returns
#' neut The neutralising antibody titre (as a fold of convalescent) that would
#' give this VE (for this VE type)
#'
#' @examples get_neut_from_efficacy(80,3) = 1
#'
#' @import data.table
#'
#' @export
#'

get_neut_from_efficacy<-function(VE, efficacy_type=3){
  # Dont really want to load this everytime, but for the moment we are
  #log10_neut_efficacy_lookup=readRDS("efficacy_lookup_table.RDS")
  
  # For some reason we need to use the "VE" value n a dummy variable
  VEin = VE
  
  # return NA / NaN if that is what is input - for now set it to 0
  VE[is.na(VE)]=1
  
  setkeyv(log10_neut_efficacy_lookup,paste0('efficacy',efficacy_type))
  loweff=log10_neut_efficacy_lookup[J(VE), roll = 1]
  higheff=log10_neut_efficacy_lookup[J(VE), roll = -1]
  
  # This needs to be fixed cause if the first element is 0, all the rest get given NA values.
  # Indices where we haven't been given an exact value from the lookup table
  # Really need to do this on an index by index basis
  if(sum(loweff[[paste0('efficacy',efficacy_type)]]!=VE & !is.na(loweff[[paste0('efficacy',efficacy_type)]]))==length(VE)){
    log10neut = approx(c(loweff[[paste0('efficacy',efficacy_type)]],higheff[[paste0('efficacy',efficacy_type)]]),c(loweff$log10_neutR,higheff$log10_neutR), xout=VE)
  } else if (sum(is.na(loweff$log10_neutR))==length(VE)){
    log10neut = rep(-1000, length(VE)) 
  } else {
    log10neut = loweff$log10_neutR
  }
  neut = 10^log10neut
  neut[is.na(VEin)]=VEin[is.na(VEin)]
  neut
}

#' Get the neuts (raw, not log10) for a given vaccine efficacy
#'
#' `get_efficacy_from_neut` returns the efficacy value for a given antibody titre
#'
#' @description This function takes in a a neut value (as a fold of convalescent) 
#' and efficacy type and 
#' returns the corresponding neut value according to the Khoury curve
#'
#' @param neut The neutralising antibody titre as a fold of convalescent (not log10)
#' @param efficacy_type the type of efficacy where efficacy types can be:
#' \itemize{
#'   \item 1 = transmission
#'   \item 2 = infection
#'   \item 3 = symptomatic
#'   \item 4 = severe
#'   \item 5 = death
#'}
#'
#' @returns
#' eff The VE (for this VE type) that would arise from this 
#' neutralising antibody titre (as a fold of convalescent)
#'
#' @examples get_efficacy_from_neut(1,3) = 1=80
#'
#' @import data.table
#' @export
#'
get_efficacy_from_neut<-function(neut, efficacy_type=3){
  # Dont really want to load this everytime, but for the moment we are
  #log10_neut_efficacy_lookup=readRDS("efficacy_lookup_table.RDS")
  
  #print(paste0("neut=",neut))
  # For some reason we need to use the "neut" value n a dummy variable
  neut_in = neut
  
  # return NA / NaN if that is what is input - for now set it to 0
  neut[is.na(neut)]=1
  
  # if they are all NA cant do anything
  if (sum(is.na(neut))==length(neut)){
    return(neut)
  }
  setkey(log10_neut_efficacy_lookup,log10_neutR)
  loweff=log10_neut_efficacy_lookup[J(log10(neut)), roll = 1]
  higheff=log10_neut_efficacy_lookup[J(log10(neut)), roll = -1]
  #print(paste0("loweff=",loweff," higheff=",higheff))
  # Indices where we haven't been given an exact value from the lookup table
  # Really need to do this on an index by index basis
  if(sum(loweff$log10_neutR!=log10(neut) & !is.na(loweff$log10_neutR))==length(neut)){
    eff = approx(c(loweff$log10_neutR,higheff$log10_neutR),c(loweff[[paste0('efficacy',efficacy_type)]],higheff[[paste0('efficacy',efficacy_type)]]), xout=log10(neut))
  } else if (sum(is.na(loweff[[paste0('efficacy',efficacy_type)]]))==length(neut)){
      if (sum((loweff$log10_neutR < 0)==length(neut))) {eff = rep(0, length(neut))} 
      else {eff=rep(1, length(neut))}
    } else {
      eff = loweff[[paste0('efficacy',efficacy_type)]]
  }
  #print(paste0("eff=",eff))
  
  eff[is.na(neut_in)]=neut_in[is.na(neut_in)]
  eff
  
}


# Not interested in this much for now
estimate_current_efficacy = function(VE0, decay_rate, time_since_vaccination, efficacy_type){
  init_neut = get_neut_from_efficacy(VE0, efficacy_type) 
  current_neut = get_neut_over_time(init_neut, decay_rate,time_since_vaccination) 
  currentVE = get_efficacy_from_neut(current_neut, efficacy_type)
  currentVE
}

get_neut_over_time = function (starting_neut, decay_rate, time){
  if (decay_rate > 0) {decay_rate = -decay_rate}
  current_neut = starting_neut*exp(decay_rate*time)
}


## This is the code from Khoury et.al. Nature Med and Cromer et. al. Lancet Microbe
####Logistic Model
ProbRemainUninfected=function(logTitre,logk,C50){1/(1+exp(-exp(logk)*(logTitre-C50)))}


#' Extract the parameters from the khoury et al nature med 2021 paper as a list
#'
#' `LogisticModel_PercentUninfected` implements the main function 
#' from the Khoury et al paper
#'
#' @param mu_titre log_10 of the mean neutralising antibody titre
#' @param sig_titre log_10 of the standard deviation in neutralising antibody titres
#' @param logk log_10 of the slope parameter
#' @param C50 log_10 of the IC50 parameter
#' 
#' @returns the probability of a cohort with a distribution of neutralising 
#' antibodies given by N(log10(mu_titre),log10(sig_titre)^2) remaining uninfected 
#' when the relationship between neutralising antibodies and protection is defined
#' by a sigmoid curve slope parameter 10^logk and IC50 value of 10^C50
#'
#' @export
#'
LogisticModel_PercentUninfected=function(mu_titre,sig_titre,logk,C50){
  NumInteration<-max(length(mu_titre),length(sig_titre),length(logk),length(C50))
  Output<-NULL
  
  if (length(C50)==1) {
    C50=rep(C50,NumInteration)
  }
  
  if (length(logk)==1) {
    logk=rep(logk,NumInteration)
  }
  
  if (length(sig_titre)==1) {
    sig_titre=rep(sig_titre,NumInteration)
  }
  
  if (length(mu_titre)==1) {
    mu_titre=rep(mu_titre,NumInteration)
  }
  
  for (i in 1:NumInteration) {
    Step=sig_titre[i]*0.001
    IntegralVector=seq(mu_titre[i]-5*sig_titre[i],mu_titre[i]+5*sig_titre[i],by=Step)
    Output[i]=sum(ProbRemainUninfected(IntegralVector,logk[i],C50[i])*dnorm(IntegralVector,mu_titre[i],sig_titre[i]))*Step
  }
  Output
}

#' Booststrap the efficacy for a given distribution of neuts (log10 not raw) 
#' 
#' @description This function takes in a distibution of neut values (log10) and 
#' returns the bootstraped efficacy values
#'
#' @param mean_neutL The mean log10 of the neutralisation titre (as a fold of convalescent titre)
#' @param se_neutL The standard error of the log0 of the neut values
#' @param niter The number of iterations to bootstrap
#' @param efficacy_type the type of efficacy where efficacy types can be:
#' \itemize{
#'   \item 1 = transmission
#'   \item 2 = infection
#'   \item 3 = symptomatic
#'   \item 4 = severe
#'   \item 5 = death
#'}
#'
#' @returns A structure with the following elements
#' eff$eff_vect = eff_vect
#' eff$mean_eff = mean(eff_vect)
#' eff$median_eff = median(eff_vect)
#' eff$sd_eff = sd(eff_vect)
#' eff$lower95_eff = quantile(eff_vect, .025)
#' eff$upper95_eff
#' 
#' @examples bootstrap_efficacy_from_neut(0,5000,.2) generates structure for 5000 
#' iterations of convalescent antibodies with 0.2 sd on the log10 of antibody levels
#'
#' @importFrom mvtnorm rmvnorm
#'
#' @export
bootstrap_efficacy_from_neut = function(mean_neutL,se_neutL=0, niter = 1000, efficacy_type=3) {
  
  sig = SummaryTable_Efficacy_NeutRatio_SD_SEM$PooledSD[1]
  sig_sd=SummaryTable_Efficacy_NeutRatio_SD_SEM$SE_PooledSD[1]
  
  if (efficacy_type==4){
    logk_IC50=c(tail(FittedLogistic_RawEfficacy_MeanRept_SDPool_Diff_EC50_Only$estimate,3))[1:2]
    cov_logk_IC50 = solve(FittedLogistic_RawEfficacy_MeanRept_SDPool_Diff_EC50_Only$hessian)[15:16,15:16]
  } else { #if (k == 3)
    logk_IC50=c(tail(FittedLogistic_RawEfficacy_MeanRept_SDPool$estimate,2))
    cov_logk_IC50 = solve(FittedLogistic_RawEfficacy_MeanRept_SDPool$hessian)[9:10,9:10]
  } 
  # Sample from the distributions - really need to sample from a joint distibution
  logk_IC50_vect = rmvnorm(niter, mean=logk_IC50, 
                              sigma=cov_logk_IC50)
  logk_vect = logk_IC50_vect[,1]
  IC50_vect = logk_IC50_vect[,2]
  sig_vect = rnorm(niter, sig,sig_sd)
  muL_vect = rnorm(niter, mean_neutL, se_neutL)
  
  eff_vect = LogisticModel_PercentUninfected(muL_vect, sig_vect, logk_vect, IC50_vect)
  eff = NULL
  eff$eff_vect = eff_vect
  eff$central_estimate_eff =LogisticModel_PercentUninfected(mean_neutL, sig, logk_IC50[1], logk_IC50[2])
  eff$mean_eff = mean(eff_vect)
  eff$median_eff = median(eff_vect)
  eff$sd_eff = sd(eff_vect)
  eff$lower95_eff = quantile(eff_vect, .025)
  eff$upper95_eff =  quantile(eff_vect, .975)
  eff
}

#' return reported neuts as a fold of convalescent from original nat med paper
#' 
#' @description This function returns the neut values (as a fold of convalescent) 
#' for various vaccines used in the original nature medicine paper.
#'
#' @param vaccine The name of the vaccine in question. Options are upper or lower case, 
#' with or without punctuation versions of
#' \itemize{
#'   \item "BNT162b2" or "Pfizer" or "Pz" or "Pfz"
#'   \item "mRNA-1273" or "moderna"
#'   \item "Gam-COVID-Vac"
#'   \item "NVX-CoV2373" or "novavax" or "nvx"
#'   \item "Ad26.COV2.S" or "JnJ" or "JJ"
#'   \item "ChAdOx1 nCoV-19" or "Astra Zeneca" or "AZ" or "Astra"
#'   \item "CoronaVac" 
#'   \item "Convalescent" or "Conv"
#'}
#' @param useLog10 = TRUE whether or not to return the log10 value
#'
#' @returns the reported neut values for the vaccine used int he main analysis
#' 
#' @examples get_original_vaccine_neuts("BNT162b2") = 0.3751770
#'
#' @export

get_original_vaccine_neuts = function(vaccine, useLog10 = TRUE){
  simpl = function(x){
    gsub("[[:punct:][:blank:]]+", "", tolower(x))
  }
  
  vaccines = list()
  vaccines[[1]] = simpl(c("BNT162b2","Pfizer","Pz","Pfz"))
  vaccines[[2]] = simpl(c("mRNA-1273","moderna"))
  vaccines[[3]] = simpl(c("Gam-COVID-Vac"))
  vaccines[[4]] = simpl(c("NVX-CoV2373","novavax","nvx"))
  vaccines[[5]] = simpl(c("Ad26.COV2.S","JnJ","JJ"))
  vaccines[[6]] = simpl(c("ChAdOx1 nCoV-19","Astra Zeneca","AZ","Astra"))
  vaccines[[7]] = simpl(c("CoronaVac" ))
  vaccines[[8]] = simpl(c("Convalescent","Conv"))
  vax = simpl(vaccine)
  
  inside = function(x, y) {y %in% x}
  vax_num = which(sapply(vaccines, inside, vax))
  if(length(vax_num)==0){
    return_val = NA
    return
  }
  
  neutL = SummaryTable_Efficacy_NeutRatio_SD_SEM$NeutRatio_Reported[vax_num] 
  
  if(useLog10){
    return_val = neutL
  } else {
    neut = 10^neutL
    return_val = neut
  }
  return_val
}

#' Booststrap the efficacy for a given distribution of neuts (log10 not raw) 
#' 
#' @description This function takes in a distibution of neut values (log10) and 
#' returns the bootstraped efficacy values
#'
#' @param mean_neutL The neutralisation titre (as a fold of convalescent titre)
#' @param efficacy_type the type of efficacy where efficacy types can be:
#' \itemize{
#'   \item 1 = transmission
#'   \item 2 = infection
#'   \item 3 = symptomatic
#'   \item 4 = severe
#'   \item 5 = death
#'}
#'
#' @returns The extimate of efficacy
#' 
#' @examples get_efficacy_from_neut_exact(.5) efficacy for antibodies that are half of convalescent
#'
#' @export
get_efficacy_from_neut_exact = function(mean_neut, efficacy_type=3) {
  
  mean_neutL = log10(mean_neut)
  print(glue("neut = {mean_neut} or log10 = {mean_neutL}"))
  sig = SummaryTable_Efficacy_NeutRatio_SD_SEM$PooledSD[1]
  
  if (efficacy_type==4){
    logk_IC50=c(tail(FittedLogistic_RawEfficacy_MeanRept_SDPool_Diff_EC50_Only$estimate,3))[1:2]
    cov_logk_IC50 = solve(FittedLogistic_RawEfficacy_MeanRept_SDPool_Diff_EC50_Only$hessian)[15:16,15:16]
  } else { #if (k == 3)
    logk_IC50=c(tail(FittedLogistic_RawEfficacy_MeanRept_SDPool$estimate,2))
    cov_logk_IC50 = solve(FittedLogistic_RawEfficacy_MeanRept_SDPool$hessian)[9:10,9:10]
  } 
  
  central_estimate_eff =LogisticModel_PercentUninfected(mean_neutL, sig, logk_IC50[1], logk_IC50[2])
  central_estimate_eff
}

